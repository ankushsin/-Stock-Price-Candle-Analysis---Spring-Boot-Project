package com.investoBull;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InvestoBullAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(InvestoBullAssignmentApplication.class, args);
	}

}
