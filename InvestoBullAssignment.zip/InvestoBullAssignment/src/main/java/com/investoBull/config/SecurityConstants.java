package com.investoBull.config;

public interface SecurityConstants {

	public static final String JWT_KEY ="secretsfhsfjhdkjngdfjkgfgjdlkfjsdkfjsd";
	public static final String JWT_HEADER = "Authorization";
	public static final long JWT_VALID_TILL = 800000L;
	
	
	
}
