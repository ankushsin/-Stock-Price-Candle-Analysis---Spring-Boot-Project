package com.investoBull.Exceptions;

public class InvalidInputException extends RuntimeException {

	public InvalidInputException() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public InvalidInputException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	

}
