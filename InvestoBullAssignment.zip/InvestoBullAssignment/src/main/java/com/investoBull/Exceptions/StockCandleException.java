package com.investoBull.Exceptions;

public class StockCandleException extends RuntimeException {

	public StockCandleException() {
		// TODO Auto-generated constructor stub
	}



	public StockCandleException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
	

}
